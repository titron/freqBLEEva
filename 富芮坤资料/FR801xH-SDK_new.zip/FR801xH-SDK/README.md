BRIEFING

Freqchip Bluetooth low energy SDK for FR801x SOC series (FR8012H/FR8016H/FR8018H). This SDK has been verified on Freqchip official EVM.
富芮坤低功耗蓝牙软件开发包(BLE SDK)适用于该公司出品的FR801X系列低功耗蓝牙SOC芯片(FR8012H/FR8016H/FR8018H)。 该SDK适用于富芮坤公司出品的官方EVM。

CONTENTS

./examples:
All the sample codes we provide. More examples are added from time to time.
包含各种例程代码，后续会不停添加更多

./components:
Specific codes related to BLE stack and the relevant profiles.
蓝牙协议栈接口及相应的profile。

./tools:
The tools for debugging and flashing.
调试烧录相关的工具等

BUILDING IMAGE

KEIL V5.23 recommended
Open the relevant project file and build the target
Easy to find the target image in the folder Output
MORE

Feel free to access the developer forum: http://www.freqchip.net .
开发者论坛： http://www.freqchip.net
WeChat Public Account: FREQCHIP .
微信公众号：FREQCHIP。
