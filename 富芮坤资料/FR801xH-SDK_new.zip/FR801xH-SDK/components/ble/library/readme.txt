libfr8010h_stack.a and syscall_gcc.txt are used by GCC tool chain
fr8010h_stack.lib and syscall.txt are used by Keil