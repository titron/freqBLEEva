/**
 * Copyright (c) 2019, Freqchip
 * 
 * All rights reserved.
 * 
 * 
 */

#ifndef MESH_SIG_MODEL_ID_H
#define MESH_SIG_MODEL_ID_H

/*
 * INCLUDES (����ͷ�ļ�)
 */
#include <stdio.h>
#include <string.h>
#include <stdint.h>


/*
 * MACROS (�궨��)
 */

/*
 * CONSTANTS (��������)
 */
#define GEN_ON_OFF_SERVER_MODEL_ID                      0x1000
#define GEN_LEVEL_SERVER_MODEL_ID                       0x1002
#define GEN_DEFAULT_TRANSTION_TIME_SERVER_MODEL_ID      0x1004


#define LIGHT_LIGHTNESS_SERVER_MODEL_ID                 0x1300

/*
 * TYPEDEFS (���Ͷ���)
 */


/*
 * GLOBAL VARIABLES (ȫ�ֱ���)
 */

/*
 * LOCAL VARIABLES (���ر���)
 */


/*
 * PUBLIC FUNCTIONS (ȫ�ֺ���)
 */





#endif







