#ifndef __CRC32_H__
#define __CRC32_H__

#ifdef __cplusplus
extern "C" {
#endif
unsigned int crc32(unsigned int crc, const unsigned char *buf, unsigned int len);

#ifdef __cplusplus
}
#endif

#endif

